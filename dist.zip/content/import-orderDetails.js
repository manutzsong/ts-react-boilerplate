(function () {

	const importPath = /*@__PURE__*/JSON.parse('"content/orderDetails.js"');

	import(chrome.runtime.getURL(importPath));

}());
