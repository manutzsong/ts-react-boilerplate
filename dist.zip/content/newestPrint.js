import { l } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/lazadaAPI-463cb048.js';
import { G } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/genStudentBill-bbeee2ed.js';
import { u } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/utils-0be93308.js';
import '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/commonjsHelpers-850449cf.js';
import '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/index-esm-33bad1f3.js';

/* eslint-disable prefer-const */
let intervalButtons;
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // listen for messages sent from background.js
    if (request.message === 'hello!') { // this we will reinject the url
        console.log(request.details); // new url is now in content scripts!
        clearInterval(intervalButtons); // clear the inverval
        init(); // reinject the script
    }
});
const init = async () => {
    var _a, _b;
    const addressRes = await l.getAddress();
    console.log(addressRes);
    const toolbarContainer = await u.waitForElement('.list-toolbar .order-toolbar-actions .order-toolbar-actions-left');
    /* manipulate add button */
    toolbarContainer.insertAdjacentHTML('afterbegin', `
    <div style="padding-right: 1rem;">
      <button disabled class="next-btn next-medium next-btn-primary aplus-auto-clk aplus-auto-exp" id="print">Print Dropoff</button>
      <button disabled class="next-btn next-medium next-btn-primary aplus-auto-clk aplus-auto-exp" id="print-student">Print Dropoff + ใบเสร็จ</button>
    </div>
  `);
    (_a = document
        .getElementById('print')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', () => getOrders(false));
    (_b = document
        .getElementById('print-student')) === null || _b === void 0 ? void 0 : _b.addEventListener('click', () => getOrders(true));
    intervalButtons = setInterval(() => {
        const checkBoxElement = document.querySelector('.list-toolbar-head .next-checkbox-input');
        const printElem = document.getElementById('print');
        const printBillElem = document.getElementById('print-student');
        if (checkBoxElement && checkBoxElement.attributes['aria-checked'] && printElem && printBillElem) {
            if (checkBoxElement.attributes['aria-checked'].value === 'true' ||
                checkBoxElement.attributes['aria-checked'].value === 'mixed') {
                if (printElem && printBillElem) {
                    printElem.disabled = false;
                    printBillElem.disabled = false;
                }
            }
            else {
                printElem.disabled = true;
                printBillElem.disabled = true;
            }
        }
    }, 200);
};
init();
const getOrders = async (bill) => {
    const ordersElem = document.querySelectorAll('div.list-item-header');
    const filteredInputChecked = [...ordersElem].filter((z) => { var _a, _b; return ((_b = (_a = z.querySelector('input')) === null || _a === void 0 ? void 0 : _a.attributes['aria-checked']) === null || _b === void 0 ? void 0 : _b.value) === 'true'; });
    const orderIds = filteredInputChecked.flatMap((z) => { var _a, _b; return (_b = (_a = z.querySelector(".order-field-value a")) === null || _a === void 0 ? void 0 : _a.textContent) !== null && _b !== void 0 ? _b : ""; });
    console.log(orderIds, filteredInputChecked);
    const orderIdsPromises = orderIds.map((orderId) => l.getOrders(orderId));
    const ordersResults = await Promise.all(orderIdsPromises);
    const printLabelPromises = ordersResults.map((x) => {
        var _a;
        const orderId = x.data.data[0].orderNumber;
        const tradeOrderLineIds = (_a = x.data.data[6].dataSource) === null || _a === void 0 ? void 0 : _a.map(
        // tradeOrderLineIds are each item id in the order
        (x) => x.orderLineId);
        return l.getPrintLabel(orderId, tradeOrderLineIds);
    });
    const printLabelResults = await Promise.all(printLabelPromises);
    console.log(printLabelResults);
    G(ordersResults, printLabelResults, bill);
};
