import { l } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/lazadaAPI-463cb048.js';
import { G } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/genStudentBill-bbeee2ed.js';
import { u } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/utils-0be93308.js';
import '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/commonjsHelpers-850449cf.js';
import '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/index-esm-33bad1f3.js';

/* eslint-disable prefer-const */
let intervalButtons;
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // listen for messages sent from background.js
    if (request.message === 'hello!') { // this we will reinject the url
        console.log(request.details); // new url is now in content scripts!
        clearInterval(intervalButtons); // clear the inverval
        init(); // reinject the script
    }
});
const init = async () => {
    var _a, _b;
    const addressRes = await l.getAddress();
    console.log(addressRes);
    const toolbarContainer = await u.waitForElement('div.toolbar-container');
    /* manipulate add button */
    toolbarContainer.insertAdjacentHTML('afterbegin', `
    <div>
      <button class="next-btn next-medium next-btn-primary aplus-auto-clk aplus-auto-exp" id="print">Print Dropoff</button>
        <button class="next-btn next-medium next-btn-primary aplus-auto-clk aplus-auto-exp" id="print-student">Print Dropoff + ใบเสร็จ</button>
    </div>
  `);
    (_a = document
        .getElementById('print')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', () => getOrders(false));
    (_b = document
        .getElementById('print-student')) === null || _b === void 0 ? void 0 : _b.addEventListener('click', () => getOrders(true));
    intervalButtons = setInterval(() => {
        const checkBoxElement = document.querySelector("div.next-table-cell-wrapper .next-checkbox-input");
        const printElem = document.getElementById("print");
        const printBillElem = document.getElementById("print-student");
        if (checkBoxElement && checkBoxElement.attributes["aria-checked"]) {
            if (checkBoxElement.attributes["aria-checked"].value === "true" || checkBoxElement.attributes["aria-checked"].value === "mixed") {
                if (printElem && printBillElem) {
                    printElem.disabled = false;
                    printBillElem.disabled = false;
                }
            }
            else {
                printElem.disabled = true;
                printBillElem.disabled = true;
            }
        }
    }, 200);
};
init();
const getOrders = async (bill) => {
    const aElements = document.querySelectorAll('a');
    if (aElements) {
        const orders = [...aElements]
            .filter((elm) => [...elm.attributes].some((attrib) => attrib.name.startsWith('data-more')))
            .filter((a) => {
            var _a, _b, _c, _d;
            return (_d = (_c = (_b = (_a = a === null || a === void 0 ? void 0 : a.parentElement) === null || _a === void 0 ? void 0 : _a.parentElement) === null || _b === void 0 ? void 0 : _b.previousElementSibling) === null || _c === void 0 ? void 0 : _c.querySelector('input')) === null || _d === void 0 ? void 0 : _d.checked;
        });
        const orderIds = orders.flatMap((a) => { var _a; return (_a = a.textContent) !== null && _a !== void 0 ? _a : ''; });
        const orderIdsPromises = orderIds.map((orderId) => l.getOrders(orderId));
        const ordersResults = await Promise.all(orderIdsPromises);
        const printLabelPromises = ordersResults.map((x) => {
            var _a;
            const orderId = x.data.data[0].orderNumber;
            const tradeOrderLineIds = (_a = x.data.data[6].dataSource) === null || _a === void 0 ? void 0 : _a.map(
            // tradeOrderLineIds are each item id in the order
            (x) => x.orderLineId);
            return l.getPrintLabel(orderId, tradeOrderLineIds);
        });
        const printLabelResults = await Promise.all(printLabelPromises);
        console.log(printLabelResults);
        G(ordersResults, printLabelResults, bill);
    }
};
