import { l } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/lazadaAPI-463cb048.js';
import { u } from '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/utils-0be93308.js';
import '../Users/Song/Documents/GitHub/ts-react-boilerplate/chunks/commonjsHelpers-850449cf.js';

const init = async () => {
    var _a;
    const sectionBox = await u.waitForElement('.next-box.section-box');
    const orderIdElement = await u.waitForElement('span.order-detail-title-number');
    const orderHeader = await u.waitForElement("div.next-card-header-title");
    const orderId = (_a = orderIdElement.textContent) === null || _a === void 0 ? void 0 : _a.split(' ')[1];
    const orderResult = await l.getOrderByOrderId(orderId !== null && orderId !== void 0 ? orderId : '');
    /* manipulate add button */
    if (orderResult.data.data.pageInfo.total > 0) {
        const htmlDiv = `
    <div class="section-field">
      <div class="section-field-label">ประเภทคำสั่งซื้อ (Laqoli)</div>
      <div class="section-field-value">${orderResult.data.data.dataSource[0].paymentMethod}</div>
    </div>
    `;
        sectionBox.insertAdjacentHTML('beforeend', htmlDiv);
        /* append chat button */
        // const divAppend = document.createElement("a");
        // divAppend.className = "d-flex";
        // divAppend.style.alignItems = "center";
        // divAppend.innerHTML = `<div style="padding-right: 0.5rem;"><p style="padding: 0;margin: 0;">แชทกับลูกค้า</p></div>
        // <span class="icon-open-chat icon-asc-order icon-asc-order-chat"></span>`;
        // sectionBox.children[0].children[1].append(divAppend);
        orderHeader.className = "next-card-header-title d-flex";
        orderHeader.style.alignItems = "center";
        orderHeader.style.justifyContent = "space-between";
        const divAppend = document.createElement("a");
        divAppend.innerHTML = `
    <div class="order-header-chat-box">
        <a 
            href="${orderResult.data.data.dataSource[0].imChatLink}" 
            target="_blank" data-spm="d_chat_button" 
            aria-haspopup="true" 
            aria-expanded="false" 
            class="next-btn next-medium next-btn-primary next-btn-text chat-button aplus-auto-exp">
                <img 
                    class="user-avatar" 
                    src="https://img.alicdn.com/imgextra/i2/O1CN01r8YtY0214uDzCoqLj_!!6000000006932-2-tps-120-120.png">
                        <span class="next-btn-helper">
                        แชทกับลูกค้า</span>
                        <span class="icon-open-chat icon-asc-order icon-asc-order-chat">
                    </span>
        </a>
    </div>
`;
        orderHeader.append(divAppend);
    }
    // document
    //   .getElementById('print-student')
    //   ?.addEventListener('click', getOrders);
};
init();
