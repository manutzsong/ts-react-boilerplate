(function () {

	const importPath = /*@__PURE__*/JSON.parse('"content/transactions.js"');

	import(chrome.runtime.getURL(importPath));

}());
