(function () {

	const importPath = /*@__PURE__*/JSON.parse('"content/new_print.js"');

	import(chrome.runtime.getURL(importPath));

}());
